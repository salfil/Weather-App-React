// import preact
import { h, render, Fragment, Component } from "preact";
// import stylesheets
import style from "./../styles/style";
import style_iphone from "../button/style_iphone";
// import jquery for API calls
import $ from "jquery";
//scrollbar
import { Scrollbars } from "preact-custom-scrollbars";

("use strict");

export default class Weekly extends Component {
	constructor(props) {
		super(props);
		var Constant = require("../favs");
		var loc = Constant.favourite;
		
		var homePage = require("../home");
		var hom = homePage.unit;
		this.setState({ location: loc });
		this.setState({ unit: hom });

		if (this.state.unit == undefined){
			this.state.unit = "metric";
		}
		
		this.state.metricunits = [" m/s", " kg/m³ "]
		this.state.imperialunits  = [" mph", " lbs/ft³ "]

		

		//sets the inital arrays that will eventually store a weather property for a different day
		this.fetchWeatherData();
		this.setState({dayOverviews: ["Loading", "Loading","Loading", "Loading", "Loading", "Loading", "Loading"],});
		this.setState({dayOrders: ["Loading", "Loading","Loading", "Loading", "Loading", "Loading", "Loading"],});
		this.setState({dayWinds: ["Loading", "Loading","Loading", "Loading", "Loading", "Loading", "Loading"],});
		this.setState({dayVisibility: ["Loading", "Loading","Loading", "Loading", "Loading", "Loading", "Loading"],});
		this.setState({icons: ["Loading", "Loading","Loading", "Loading", "Loading", "Loading", "Loading"],});
		this.setState({dayHumidity: ["Loading", "Loading","Loading", "Loading", "Loading", "Loading", "Loading"],});
		this.setState({TempHi: ["Loading", "Loading","Loading", "Loading", "Loading", "Loading", "Loading"],});
		this.setState({TempLo: ["Loading", "Loading","Loading", "Loading", "Loading", "Loading", "Loading"],});
	}

	//queries the api and upon success parses the returned JSON file
	fetchWeatherData = () => {
		var city;

		var TempUnit;

		if (this.state.unit == undefined) {
			//if not then this location is the default
			TempUnit = "metric";
		} else {TempUnit = this.state.unit};

		var coords = [];
		coords = this.fetchlatlong();

		var url;
		url ="http://api.openweathermap.org/data/2.5/onecall?lat=" +coords[0] +"&lon=" +coords[1] +"&units="+TempUnit+"&appid=e3b83b162cb76e194faa1f9af02d0b8b";
		$.ajax({
			url: url,
			dataType: "jsonp",
			success: this.parseResponse,
			error: function (req, err) {
				console.log("API call failed " + err);
			},
		});
	};

	//fetches the latitude and longitude of a city from an external json fila based on its name.
	fetchlatlong = () => {
		var target;
		if (this.state.location == undefined) {
			target = "Courchevel";
		} else {
			target = this.state.location.split(',')[0];
		}
		let cities = require("../../current.city.list.min.json");

		for (var x = 0; x < cities.length; x++) {
			if (cities[x].name == target) {
				return [cities[x].coord.lat, cities[x].coord.lon];
			}
		}
	};

	// the main render method for the weekly component
	render() {

		//loops 6 times to format a 6 day forecast, and saves this to a constant.
		const items = [];
		var Temp = this.state.dayTemps;
		for (let i = 1; i < 7; i++) {
			items.push(
				<div class = {style.dayStyle}>
					<div class={style.topforecast}>
						<table class = {style.overviewtab}style={{ display: "table" }}>
							<tr>
								<td>
									<p>{this.state.dayOverviews[i]}<strong>{this.state.dayOrders[i]}</strong></p>{" "}
								</td>
								<td class = {style.wiconcont}>
									<img class={style.wiconfavs} src={this.state.icons[i]}></img>
								</td>
							</tr>
						</table>
					</div>
					<div>
						<table class ={style.weekstats} style={{ display: "table" }}>
							<tr>
								<td colspan="2"class={style.prop}>Wind</td>
								<td colspan="2" class={style.val}>
									{this.state.dayWinds[i]}
									{this.state.name == "metric"
										? this.state.metricunits[0]
										: this.state.imperialunits[0]}
								</td>
							</tr>

							<tr>
								<td colspan="2"class={style.prop}>Humidity </td>
								<td colspan="2" class={style.val}>
									{this.state.dayHumidity[i]}
									{this.state.name == "metric"
										? this.state.metricunits[1]
										: this.state.imperialunits[1]}
								</td>
							</tr>
							<tr class={style.top}>
								<td class>Hi</td>
								<td class={style.valfav}>{this.state.TempHi[i]} </td>
								<td>Lo </td>
								<td class={style.val}>{this.state.TempLo[i]}</td>
							</tr>
						</table>
					</div>
				</div>
			);
		}

		// display all weather data items for the week, and checks is a favourite is set beforehand, if it is not, i displays a message
		return (
			<Fragment>
				<div class={style.header}>
					<p>
						Weekly forecast for{" "}
						{this.state.location == undefined
							? "Courchevel"
							: this.state.location}
					</p>
					{this.state.location == undefined
							? <p><em>suggested location, please add a favourite</em></p>:<div></div> }
				</div>

				<div class={style.details}></div>
				<div class={style_iphone.container}>
					<Scrollbars class = {style.scrollfav} style={{ width: 400, height: 550}}>{items}</Scrollbars>
				</div>
			</Fragment>
		);
	}

	//formats the recieved json from the AIP query by setting arrats in the state to returned properties. 
	parseResponse = (parsed_json) => {
		var i;
		var temperatureHi = [];
		var temperatureLo = [];
		var windSpeed = [];
		var humid = [];
		var iconfuture = [];
		var overv = [];
		var iconfuturelink = [];
		var dayorder = [];
		var dayArray = [
			"Sunday",
			"Monday",
			"Tuesday",
			"Wednesday",
			"Thursday",
			"Friday",
			"Saturday",
		];

		for (i = 0; i < 7; i++) {
			//console.log(parsed_json['daily'][i]['humidity']);
			temperatureHi.push((parsed_json["daily"][i]["temp"]["max"]));
			temperatureLo.push((parsed_json["daily"][i]["temp"]["min"]));
			windSpeed.push(parsed_json["daily"][i]["wind_speed"]);
			humid.push(parsed_json["daily"][i]["humidity"]);
			var d = new Date(parsed_json["daily"][i]["dt"] * 1000);

			overv.push(
				Math.round(parsed_json["daily"][i]["temp"]["day"]) +
					"°, with " +
					parsed_json["daily"][i]["weather"]["0"]["description"] +
					" on "
			);
			dayorder.push(dayArray[d.getDay()])
			iconfuture.push(parsed_json["daily"][i]["weather"]["0"]["icon"]);
			iconfuturelink.push(
				"http://openweathermap.org/img/wn/" + iconfuture[i] + "@2x.png"
			);
		}

		this.setState({
			dayOverviews: overv,
			TempHi: temperatureHi,
			TempLo: temperatureLo,
			dayWinds: windSpeed,
			icons: iconfuturelink,
			dayHumidity: humid,
			dayOrders: dayorder
		});
	};
}
