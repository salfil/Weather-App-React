// import preact
import { h, Component, render } from 'preact';
//prreact router import to set routes to components.
import { Router } from 'preact-router';
import {Link} from 'preact-router/match';
import style from './styles/style';

// import required Components from 'components/'
import Home from './home';
import Search from './search';
import Favs from './favs'; 
import Weekly from './weekly';
import Nav from './nav';



export default class App extends Component {
//var App = React.createClass({


	// once the components are loaded, checks if the url bar has a path with "ipad" in it, if so sets state of tablet to be true

	
	/*
		A render method to display the required Component on screen (iPhone or iPad) : selected by checking component's isTablet state
	*/
	render(){
		
		return (
			<div id = "app" >
				{/* google font import for different font style */}
				<link rel="preconnect" href="https://fonts.gstatic.com"></link>
				<link href="https://fonts.googleapis.com/css2?family=Lexend:wght@100;400;700&display=swap" rel="stylesheet"></link>
				<div class = {style.container}>
				{/* router to set routes to different components */}
					<Router>
						<Home path ="/" />
						<Search path ="/search" />
						<Favs path ="/fav" />
						<Weekly path ="/week" />

						<div default> error 404  </div>
					</Router>

					<Nav />
				</div>
				
			</div>

		);
	}
}