// import preact
import { Component, h } from "preact";
// import stylesheets
import style from "./../styles/style";
//link from preact router to allow navigation to different components.
import { Link } from "preact-router/match";
//icons to display on navbar
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
	faHome,
	faCalendar,
	faSearch,
	faStar,
} from "@fortawesome/free-solid-svg-icons";

export default class Nav extends Component {
	// the main render method for the iphone component
	render() {
		// display all nav data, with components that have references/links set in the app.js file, using preact router 
		return (
			<nav class={style.bottomnav}>
				<Link activeClassName="active" href="/">
					<FontAwesomeIcon icon={faHome} /> Home{" "}
				</Link>
				<Link activeClassName="active" href="/week">
					<FontAwesomeIcon icon={faCalendar} /> Week{" "}
				</Link>
				<Link activeClassName="active" href="/search">
					<FontAwesomeIcon icon={faSearch} /> Search
				</Link>
				<Link activeClassName="active" href="/fav">
					<FontAwesomeIcon icon={faStar} /> Favourites
				</Link>
			</nav>
		);
	}
}
