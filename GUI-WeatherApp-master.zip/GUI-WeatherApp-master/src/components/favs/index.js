// import preact
import { h, render, Fragment, Component } from "preact";
// import stylesheets for ipad & button
import style from "../styles/style";
import style_iphone from "../button/style_iphone";
// import the Scrollbars component
import { Scrollbars } from "preact-custom-scrollbars";
//icons
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faStar, faEye } from "@fortawesome/free-solid-svg-icons";

export default class Favs extends Component {
	//constructor
	constructor(props) {
		super(props);
		this.setState({
			//hard coded values for favourite locations
			favourites: [
				{ name: "Vancouver, British Columbia, Canada" },
				{ name: "Aspen, Colerado, USA" },
				{ name: "Courchevel, France" },
			],

			//boolean for if a view on homepage link has been pressed
			clicked: false,
		});
	}

	//this function is called when a view on homepage anchor link is pressed
	addMainFave = (name) => {
		console.log("fave " + name + " set!");
		//export the selected city/location with the identifier 'favourite'
		module.exports = {
			favourite: name,
		};

		//set the clicked state true and the selected location to favourite
		this.setState({ clicked: true, favourite: name });
	};

	render() {
		return (
			<div class={style.container}>
				<div class={style.header}>
					<p>Favourites</p>
				</div>
				<Scrollbars style={{ width: 400, height: 500 }}>
					<div class={style_iphone.container}>
						{/*Display all favourite locations with their anchor links*/}
						{this.state.favourites.map((fav) => (
							<div>
								<nav class={style.favNav}>
									<p>{fav.name}</p>
									<a>
										<FontAwesomeIcon icon={faStar} /> Un favourite
									</a>
									<a onClick={() => this.addMainFave(fav.name)}>
										<FontAwesomeIcon icon={faEye} /> view on Hompeage
									</a>
									<div id={fav.name}></div>
								</nav>
							</div>
						))}

						{/*Confirmation text displayed when a user has selected a location (clicked view on homepage anchor)*/}
						<div>
							{this.state.clicked ? (
								<div class={style.confirmedFav}>
									<p>
										<em>You have successfully added {this.state.favourite} to the
										home screen.</em>
									</p>
								</div>
							) : null}
						</div>
					</div>
				</Scrollbars>
			</div>
		);
	}
}
