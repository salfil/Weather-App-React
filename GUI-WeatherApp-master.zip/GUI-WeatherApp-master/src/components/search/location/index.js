// import preact
import { h, render, Component } from "preact";
// styles
import style from "../../styles/style";

//import favourite icons
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faStar } from "@fortawesome/free-solid-svg-icons";
import { faStar as faEmptyStar } from "@fortawesome/free-regular-svg-icons";

export default class Location extends Component {
	//constructor
	constructor(props) {
		super(props);
		this.setState({ selected: false });
	}

	addToFavourites = () => {
		//when a favourite button has been pressed change the selected boolean state to the opposite
		//of what it was previously
		this.setState({ selected: !this.state.selected });
	};

	//render function
	render() {
		console.log("It went to Location");
		return (
			<div>
				{/*return the name of the location*/}
				{this.props.name}
				{/*Have a favourite button for each location*/}
				<button class={style.favouriteButton} onClick={this.addToFavourites}>
					{/*When a favourite button is pressed change the icon to indicate it has been pressed*/}
					{this.state.selected ? (
						<FontAwesomeIcon icon={faStar} />
					) : (
						<FontAwesomeIcon icon={faEmptyStar} />
					)}
				</button>
			</div>
		);
	}
}
