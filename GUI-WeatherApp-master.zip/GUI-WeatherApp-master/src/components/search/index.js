// import preact
import { h, render, Fragment, Component } from "preact";
// import stylesheets for ipad & button
import style from "./../styles/style";

import LocationsContainer from "./locationsContainer";

import LocationsContainer from './locationsContainer';

export default class Search extends Component {
	//var Iphone = React.createClass({

	constructor(props) {
		super(props);

		this.setState({
			//Top ski resort city locations in the world
			locations: [
				"Whistler, British Columbia, Canada",
				"Vancouver, British Columbia, Canada",
				"Courchevel, France",
				"Zermatt, Switzerland",
				"Vail, Colerado, USA",
				"Aspen, Colerado, USA",
				"Val d'Isere, Canada",
				"Cortina d'Ampezzo, Italy",
				"Telluride, Colerado, USA",
				"Niseko, Hokkaido, Japan",
				"Chamonix, Mont Blanc, France",
				"St. Anton, Tyrolean Alps, Austria",
				"Kitzbuhel, Austria",
				"Saint Moritz, Switzerland",
				"Park City, Utah, USA",
				"Rio Negro, Argentine",
			],

			//A subset of the locations to show as suggested locations
			subset: [
				"Vancouver, British Columbia, Canada",
				"Courchevel, France",
				"Zermatt, Switzerland",
				"Vail, Colerado, USA",
				"Chamonix, Mont Blanc, France",
				"St. Anton, Tyrolean Alps, Austria",
				"Rio Negro, Argentine",
			],

			//Initialise search term to empty
			searchTerm: "",
		});
	}

	//This method will change the search term to what the user has typed in the search bar
	editSearchTerm = (event) => {
		this.setState({ searchTerm: event.target.value });
	};

	//This method will return the list of locations based on what the user has typed in the search bar
	dynamicSearch = () => {
		//check if the locations have the string entered as part of them
		if (this.state.searchTerm == "") {
			//when user haven't entered anything then show the subset of all locations (suggested locations)
			return this.state.subset;
		} else {
			//otherwise filter the suggested locations to show what matches what the user is typing
			return this.state.locations.filter((name) =>
				name.toLowerCase().includes(this.state.searchTerm.toLowerCase())
			);
		}
	};

	render() {
		return (
			<Fragment>
				<div class={style.header}>
					{/*The Search bar*/}
					<input
						class={style.searchbar}
						placeholder={"Search for a location"}
						type="text"
						value={this.state.searchTerm}
						onKeyPress={this.editSearchTerm}
						onKeyDown={this.editSearchTerm}
					/>

					{/*Suggested locations to be displayed*/}
					<div class={style.header}>
						<h4>Suggested locations:</h4>
						{/*Container for displaying the locations*/}
						<LocationsContainer
							class={style.locationsContainer}
							locations={this.dynamicSearch()}
						/>
						{/*Get all locations matching search*/}
					</div>
				</div>
			</Fragment>
		);
	}
}
