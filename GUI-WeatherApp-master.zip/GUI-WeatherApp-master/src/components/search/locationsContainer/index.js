// import preact
import { h, render, Component } from "preact";

import Location from "../location";

export default class LocationContainer extends Component {
	render() {
		console.log("Went to LocationContainer");
		return (
			<div>
				{/*Gets each location name from Location component*/}
				{this.props.locations.map((name) => (
					<Location name={name} />
				))}
			</div>
		);
	}
}
