// import preact
import { h, render, Fragment, Component } from "preact";
// import stylesheets for ipad & button
import style from "./../styles/style";
import style_iphone from "../button/style_iphone";
import { Scrollbars } from "preact-custom-scrollbars";
//chartjs for hourly wather chart
import { Line, Chart } from "preact-chartjs-2";

// import jquery for API calls
import $ from "jquery";
// import the Button component
import Button from "../button";

("use strict");

export default class Home extends Component {

	// a constructor with initial set states
	constructor(props) {
		super(props);
		// temperature state
		this.state.temp = "";
		// button display state#
		this.state.name = "metric";
		this.state.metricunits = [" m/s", " kg/m³ "];
		this.state.imperialunits = [" mph", " lbs/ft³ "];
		this.setState({
			hourTemps: [
				"Loading",
				"Loading",
				"Loading",
				"Loading",
				"Loading",
				"Loading",
				"Loading",
				"Loading",
				"Loading",
				"Loading",
				"Loading",
				"Loading",
			],
		});
		this.setState({
			hourTimes: [
				"Loading",
				"Loading",
				"Loading",
				"Loading",
				"Loading",
				"Loading",
				"Loading",
				"Loading",
				"Loading",
				"Loading",
				"Loading",
				"Loading",
			],
		});

		//gets the favrouties compoents in order to grab the exported name of the favourited city selected by the user to view on the homescreen
		var Constant = require("../favs");
		var loc = Constant.favourite;
		//console.log("location in iphone: " + location);

		this.setState({ display: true, celcius: true, location: loc });
		this.fetchWeatherData();
		this.fetchWeatherDataHours();
	}

	//contstructure to check if windspeed is ok
	windSpeedCheck = () => {
		var Threshold = 10;
		if (this.speedWind <= Threshold) {
			var GoodSpeed = True;
		}
	};
	changeUnit = () => {
		if (this.state.name == "metric") {
			this.state.name = "imperial";
			//console.log("changed to f");
			//console.log(this.state.name);
		} else {
			this.state.name = "metric";
			//console.log("changed to c");
			//console.log(this.state.name);
		}
		this.fetchWeatherData();
		this.fetchWeatherDataHours();
		module.exports = {
			unit: this.state.name,
		};
	};

	// a call to fetch weather data via openweathermap
	fetchWeatherData = () => {
		//console.log("location in fetch method: "+this.state.location);

		var city;
		var TempUnit = this.state.name;

		//this will check if a favourite location to view on homepage has been selected
		if (this.state.location == undefined) {
			//if not then this location is the default
			city = "Courchevel";
		} else {
			//otherwise set the location to the selected location from the favourite screen
			city = this.state.location.split(",")[0];
		}

		// API URL with a structure of :

		var url;
		url =
			"http://api.openweathermap.org/data/2.5/weather?q=" +
			city +
			"&units=" +
			TempUnit +
			"&appid=e3b83b162cb76e194faa1f9af02d0b8b";
		$.ajax({
			url: url,
			dataType: "jsonp",
			success: this.parseResponse,
			error: function (req, err) {
				console.log("API call failed " + err);
			},
		});

		//console.log("windspeed" + this.state.speedWind);
	};
	// a openweathermap call to get hourly data.
	fetchWeatherDataHours = () => {
		//console.log(this.state.name);

		var TempUnit;

		if (this.state.unit == undefined) {
			//if not then this location is the default

			TempUnit = "metric";
		} else {
			TempUnit = this.state.unit;
		}

		var coords = [];
		coords = this.fetchlatlong();

		// API URL with a structure of :

		var url;
		url =
			"http://api.openweathermap.org/data/2.5/onecall?lat=" +
			coords[0] +
			"&lon=" +
			coords[1] +
			"&units=" +
			TempUnit +
			"&appid=e3b83b162cb76e194faa1f9af02d0b8b";
		$.ajax({
			url: url,
			dataType: "jsonp",
			success: this.parseResponseHours,
			error: function (req, err) {
				console.log("API call failed " + err);
			},
		});
	};


	//fetches the latitude and longitude of a city from an external json fila based on its name.
	fetchlatlong = () => {
		var target;
		if (this.state.location == undefined) {
			target = "Courchevel";
		} else {
			target = this.state.location.split(",")[0];
			//target = "London"
		}
		let cities = require("../../current.city.list.min.json");

		for (var x = 0; x < cities.length; x++) {
			if (cities[x].name == target) {
				return [cities[x].coord.lat, cities[x].coord.lon];
			}
		}
	};

	// the main render method for the iphone component
	render() {
		// check if temperature data is fetched, if so add the sign styling to the page
		const tempStyles = this.state.temp
			? `${style.temperature} ${style.filled}`
			: style.temperature;

		// display all weather data
		const data = {
			labels: this.state.hourTimes,
			datasets: [
				{
					label: "your day",
					fill: false,
					lineTension: 0.1,
					//height: 600,
					//scaleShowLabels : false,
					backgroundColor: "rgba(63, 64, 69, 1)",
					borderColor: "rgba(255,255,255,1)",
					borderCapStyle: "butt",
					borderDash: [],
					borderDashOffset: 0.0,
					borderJoinStyle: "miter",
					labelFontColor: "green",
					pointBorderColor: "rgba(75,192,192,1)",
					//strokeColour : "rgba(0, 255, 0, 1)",
					pointBackgroundColor: "rgba(255, 255, 255, 1)",
					pointBorderWidth: 1,
					pointHoverRadius: 5,
					pointHoverBackgroundColor: "rgba(63, 64, 69, 1)",
					pointHoverBorderColor: "rgba(220,220,220,1)",
					pointHoverBorderWidth: 2,
					pointRadius: 1,
					pointHitRadius: 10,
					data: this.state.hourTemps,
				},
			],
		};
		const opt = {
			padding: "0px",
			//responsive:false,
			maintainAspectRatio: false,
			responsive: false,
			height: "800",
			width: "400",
			// legend: {
			// 	labels: {
			// 		// This more specific font property overrides the global property
			// 		fontColor: "white",
			// 	},
			// 	scales: {
			// 		xAxes: [{
			// 			ticks: {
			// 				display: true,
			// 				fontColor: 'red'
			// 			},
			// 		}]
			// 	}
			// },
		};
		Chart.defaults.global.defaultFontColor = "white";
		return (
			<Fragment>
				{/* toggle to change units from imperial to metric, clickeing it changes a state variable, and re renders the window after re-calling the api with the new Unit parameter. */}
				<div>
					<button onClick={this.changeUnit} class={style.toggle}>
						Change units to{" "}
						{this.state.name == "metric" ? "Fahrenheit" : "Celsius"}
					</button>
				</div>

				<div class={style.header}>
					{/* displays a message if the user hasn't selected a favourite/ the location state hasn't been set or gotten from the favorutes page yet. */}
					{this.state.location == undefined ? (
						<p>
							<em>suggested location, please add a favourite</em>
						</p>
					) : (
						<div></div>
					)}
					<div class={style.city}>{this.state.locate}</div>

					<div class={style.conditions}>{this.state.cond}</div>

					<div>
						<img class={style.wiconhome} src={this.state.ic}></img>
						<span class={tempStyles}>{this.state.temp}</span>
					</div>
				</div>

				<div class={style.details}></div>
				<div class={style_iphone.container}>
					<Scrollbars style={{ width: 400, height: 399 }}>
						<div style>
							<table style={{ display: "table" }}>
								<tr>
									<td class={style.prop}>
										{/* suggestion / info about wind speed */}
										{/* displays weathher info in a table, with condtional statemts to display the correct units */}
										Wind Speed{this.state.tooFast
											? " (fast)"
											: " (suitable)"}:{" "}
									</td>
									<td class={style.val}>
										{this.state.speedWind}
										{this.state.name == "metric"
											? this.state.metricunits[0]
											: this.state.imperialunits[0]}
									</td>
								</tr>

								<tr>
									<td class={style.prop}>Visibility: </td>
									<td class={style.val}>{this.state.visible / 1000} km</td>
								</tr>

								<tr>
									<td class={style.prop}>Humidity: </td>
									<td class={style.val}>
										{this.state.Humid}
										{this.state.name == "metric"
											? this.state.metricunits[1]
											: this.state.imperialunits[1]}
									</td>
								</tr>
							</table>
						</div>
						<div>
							<div class={style.header}>
								<div class={style.tip}>
									{this.state.tooHot ? ( //states whether temperature is good or not for skiing.
										<p1> Not ideal skiing temp</p1>
									) : (
										<p1>Suitable skiing temperature</p1>
									)}
								</div>
							</div>

							<div class={style.header}>
								<div class={style.tip}>
									{this.state.GoodForSki ? (
										<p1>Good for skiing!</p1>
									) : (
										<p1>Unsuitable for sking</p1>
									)}
								</div>
							</div>
							<div class={style.hourly}>
								<Line data={data} />
							</div>
						</div>
					</Scrollbars>
				</div>
			</Fragment>
		);
	}

	//processesjson from day forecast wather call and sets the home object state with thses values so they can be used later on/
	parseResponse = (parsed_json) => {
		var location = parsed_json["name"];
		var temp_c = Math.round(parsed_json["main"]["temp"]);
		var conditions = parsed_json["weather"]["0"]["description"];
		var icon = parsed_json["weather"]["0"]["icon"];

		var Wspeed = parsed_json["wind"]["speed"];
		var visib = parsed_json["visibility"];
		var Phumidity = parsed_json["main"]["temp"];

		// set states for fields so they could be rendered later on
		this.setState({
			locate: location,
			temp: temp_c,
			cond: conditions,
			speedWind: Wspeed,
			visible: visib,
			ic: "http://openweathermap.org/img/wn/" + icon + "@2x.png",
			Humid: Phumidity,
		});
		if (this.state.speedWind < 3 || this.state.temp < 0) {
			//console.log("it went here");
			this.setState({ GoodForSki: true });
			this.state.tooHot = false;
		} else {
			if (this.state.temp > 0) {
				//check if temperature is ideal for skiing.
				this.setState({ tooHot: true });
			}

			if (this.state.speedWind > 3) {
				//checks if the windspeed is good for skiing.
				this.setState({ tooFast: true });
			}
			this.setState({ GoodForSki: false });
		}
	};

	//uses json file from weather api call for the next 12 hours and sets the data retuned to values in a state array, so they can then be rendered on a chart
	parseResponseHours = (parsed_json) => {
		var i;
		var hours = [];
		var temps = [];

		for (i = 0; i < 12; i++) {
			//console.log(parsed_json['daily'][i]['humidity']);
			temps.push(parsed_json["hourly"][i]["feels_like"]);

			var d = new Date(parsed_json["hourly"][i]["dt"] * 1000);
			hours.push(d.getHours() + ":00");
		}

		this.setState({
			hourTemps: temps,
			hourTimes: hours,
		});
	};
}
